import os
import speech_recognition as sr
from googletrans import Translator

# Function to transcribe the audio using Google's Speech Recognition API
def transcribe_audio(audio_path):
    r = sr.Recognizer()
    with sr.AudioFile(audio_path) as source:
        audio = r.record(source)
    text = r.recognize_google(audio)
    return text

# Function to translate text using Google Translate API
def translate_text(text, target_language):
    translator = Translator()
    translation = translator.translate(text, dest=target_language)
    return translation.text

# Path to the audio file
audio_file_path = "path/to/audio/file.wav"

# Preferred language for translation
target_language = "fr"  # Replace with the desired language code

# Transcribe the audio
transcribed_text = transcribe_audio(audio_file_path)

# Translate the transcribed text
translated_text = translate_text(transcribed_text, target_language)

# Output the translated text
print(translated_text)
