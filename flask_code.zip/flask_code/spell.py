import tkinter as tk
from tkinter import messagebox

# Dictionary with image paths and their corresponding correct words
image_word_mapping = {
    "images/apple.jpg": "apple",
    "images/banana.jpg": "banana",
    "images/grape.jpeg": "orange",
    "images/orange.jpg": "grape",
    "images/watermelon.jpg": "watermelon",
}

class SpellingTestApp(tk.Tk):
    def __init__(self):
        super().__init__()

        self.title("Spelling Test")
        self.geometry("400x250")

        self.label = tk.Label(self, text="Select the correct word for the picture:")
        self.label.pack(pady=10)

        self.image_label = tk.Label(self)
        self.image_label.pack(pady=10)

        self.word_options = tk.StringVar(self)
        self.word_options.set("Choose a word")  # Default text for dropdown
        self.dropdown = tk.OptionMenu(self, self.word_options, *image_word_mapping.values())
        self.dropdown.pack(pady=10)

        self.submit_button = tk.Button(self, text="Submit", command=self.check_answer)
        self.submit_button.pack(pady=10)

        # Start the test by displaying the first image and options
        self.current_image_path, self.correct_word = next(iter(image_word_mapping.items()))
        self.update_image_and_options()

    def update_image_and_options(self):
        image = tk.PhotoImage(file=self.current_image_path)
        self.image_label.configure(image=image)
        self.image_label.image = image  # To prevent garbage collection

        # Shuffle the word options to avoid fixed positions
        options = list(image_word_mapping.values())
        import random
        random.shuffle(options)
        self.word_options.set("Choose a word")  # Reset the dropdown default text
        self.dropdown["menu"].delete(0, "end")  # Clear previous options
        for word in options:
            self.dropdown["menu"].add_command(label=word, command=lambda value=word: self.word_options.set(value))

    def check_answer(self):
        selected_word = self.word_options.get()
        if selected_word == self.correct_word:
            messagebox.showinfo("Result", "Correct! Well done!")
        else:
            messagebox.showerror("Result", f"Wrong! The correct word was '{self.correct_word}'.")

        # Move to the next image and update the options
        try:
            self.current_image_path, self.correct_word = next(iter(image_word_mapping.items()))
            self.update_image_and_options()
        except StopIteration:
            # If all images have been displayed, show a message and exit the app
            messagebox.showinfo("Finished", "You have completed the Spelling Test!")
            self.destroy()

if __name__ == "__main__":
    app = SpellingTestApp()
    app.mainloop()
